-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: localhost    Database: book_management
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `books`
--

LOCK TABLES `books` WRITE;
/*!40000 ALTER TABLE `books` DISABLE KEYS */;
INSERT INTO `books` VALUES (1,'Book 21','Title 21','Author 21',2023),(2,'Book 22','Title 22','Author 22',2022),(3,'Book 23','Title 23','Author 23',2021),(4,'Book 24','Title 24','Author 24',2020),(5,'Book 25','Title 25','Author 25',2019),(6,'Book 26','Title 26','Author 26',2023),(7,'Book 27','Title 27','Author 27',2022),(8,'Book 28','Title 28','Author 28',2021),(9,'Book 29','Title 29','Author 29',2020),(10,'Book 30','Title 30','Author 30',2019),(11,'Book 31','Title 31','Author 31',2023),(12,'Book 32','Title 32','Author 32',2022),(13,'Book 33','Title 33','Author 33',2021),(14,'Book 34','Title 34','Author 34',2020),(15,'Book 35','Title 35','Author 35',2019),(16,'Book 36','Title 36','Author 36',2023),(17,'Book 37','Title 37','Author 37',2022),(18,'Book 38','Title 38','Author 38',2021),(19,'Book 39','Title 39','Author 39',2020),(20,'Book 40','Title 40','Author 40',2019),(21,'Book 41','Title 41','Author 41',2023),(22,'Book 42','Title 42','Author 42',2022),(23,'Book 43','Title 43','Author 43',2021),(24,'Book 44','Title 44','Author 44',2020),(25,'Book 45','Title 45','Author 45',2019),(26,'Book 46','Title 46','Author 46',2023),(27,'Book 47','Title 47','Author 47',2022),(28,'Book 48','Title 48','Author 48',2021),(29,'Book 49','Title 49','Author 49',2020),(30,'Book 50','Title 50','Author 50',2019),(31,'Book 51','Title 51','Author 51',2023),(32,'Book 52','Title 52','Author 52',2022),(33,'Book 53','Title 53','Author 53',2021),(34,'Book 54','Title 54','Author 54',2020),(35,'Book 55','Title 55','Author 55',2019),(36,'Book 56','Title 56','Author 56',2023),(37,'Book 57','Title 57','Author 57',2022),(38,'Book 58','Title 58','Author 58',2021),(39,'Book 59','Title 59','Author 59',2020),(40,'Book 60','Title 60','Author 60',2019),(41,'Book 61','Title 61','Author 61',2023),(42,'Book 62','Title 62','Author 62',2022),(43,'Book 63','Title 63','Author 63',2021),(44,'Book 64','Title 64','Author 64',2020),(45,'Book 65','Title 65','Author 65',2019),(46,'Book 66','Title 66','Author 66',2023),(47,'Book 67','Title 67','Author 67',2022),(48,'Book 68','Title 68','Author 68',2021),(49,'Book 69','Title 69','Author 69',2020),(50,'Book 70','Title 70','Author 70',2019),(51,'Book 71','Title 71','Author 71',2023),(52,'Book 72','Title 72','Author 72',2022),(53,'Book 73','Title 73','Author 73',2021),(54,'Book 74','Title 74','Author 74',2020),(55,'Book 75','Title 75','Author 75',2019),(56,'Book 76','Title 76','Author 76',2023),(57,'Book 77','Title 77','Author 77',2022),(58,'Book 78','Title 78','Author 78',2021),(59,'Book 79','Title 79','Author 79',2020),(60,'Book 80','Title 80','Author 80',2019),(61,'Book 81','Title 81','Author 81',2023),(62,'Book 82','Title 82','Author 82',2022),(63,'Book 83','Title 83','Author 83',2021),(64,'Book 84','Title 84','Author 84',2020),(65,'Book 85','Title 85','Author 85',2019),(66,'Book 86','Title 86','Author 86',2023),(67,'Book 87','Title 87','Author 87',2022),(68,'Book 88','Title 88','Author 88',2021),(69,'Book 89','Title 89','Author 89',2020),(70,'Book 90','Title 90','Author 90',2019),(71,'Book 91','Title 91','Author 91',2023),(72,'Book 92','Title 92','Author 92',2022),(73,'Book 93','Title 93','Author 93',2021),(74,'Book 94','Title 94','Author 94',2020),(75,'Book 95','Title 95','Author 95',2019),(76,'Book 96','Title 96','Author 96',2023),(77,'Book 97','Title 97','Author 97',2022),(78,'Book 98','Title 98','Author 98',2021),(79,'Book 99','Title 99','Author 99',2020),(80,'Book 100','Title 100','Author 100',2019);
/*!40000 ALTER TABLE `books` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-02 20:09:16
